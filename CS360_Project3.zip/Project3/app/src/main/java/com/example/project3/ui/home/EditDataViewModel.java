package com.example.project3.ui.home;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.project3.R;
import com.example.project3.data.InventoryDataSource;

import java.io.IOException;

public class EditDataViewModel extends ViewModel {

    private MutableLiveData<com.example.project3.ui.home.EditDataFormState> editDataFormState = new MutableLiveData<>();
    private InventoryDataSource dataSource;

    public EditDataViewModel() {
    }

    LiveData<com.example.project3.ui.home.EditDataFormState> getEditDataFormState() {
        return editDataFormState;
    }


    public void InitializeDataProvider(Context context) {
        dataSource = new InventoryDataSource(context);
    }


    public void addDataDataChanged(String productCount) {
        if (!isValidNumber(productCount)) {
            editDataFormState.setValue(new com.example.project3.ui.home.EditDataFormState(R.string.invalid_productCount));
        } else {
            editDataFormState.setValue(new com.example.project3.ui.home.EditDataFormState(true));
        }
    }


    public void UpdateRecordCount(String id, String count) throws IOException {
        try {
            // Insert a record
            dataSource.updateInventoryDatabase(id, count);
        } catch (Exception e) {
            throw new IOException("Error updating record", e);
        }
    }

    private boolean isStringValid(String sys) {
        return sys != null && sys.trim().length() > 3;
    }


    private boolean isValidNumber(String sys) {
        try {
            int i = Integer.parseInt(sys);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
