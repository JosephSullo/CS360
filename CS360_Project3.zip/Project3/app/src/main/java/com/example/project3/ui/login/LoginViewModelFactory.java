package com.example.project3.ui.login;

import android.content.Context;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.annotation.NonNull;

import com.example.project3.data.LoginDataSource;
import com.example.project3.data.LoginRepository;

public class LoginViewModelFactory implements ViewModelProvider.Factory {

    private android.content.Context AppContext;

    public LoginViewModelFactory(Context context) {
        super();

        AppContext = context;
    }

    @NonNull
    @Override
    @SuppressWarnings("unchecked")
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(com.example.project3.ui.login.LoginViewModel.class)) {
            return (T) new com.example.project3.ui.login.LoginViewModel(LoginRepository.getInstance(new LoginDataSource(AppContext)));
        } else {
            throw new IllegalArgumentException("Unknown ViewModel class");
        }
    }
}