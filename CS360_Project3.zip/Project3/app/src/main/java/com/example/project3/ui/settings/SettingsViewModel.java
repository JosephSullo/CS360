package com.example.project3.ui.settings;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.project3.data.InventoryDataSource;

import java.util.jar.Manifest;

public class SettingsViewModel extends ViewModel {

    private InventoryDataSource dataSource;

    public SettingsViewModel() {

    }

    public void InitializeDataProvider(Context context) {
        dataSource = new InventoryDataSource(context);
    }

    public boolean DeleteAllInventoryData() {
        return dataSource.deleteAllInventoryData();
    }

}
