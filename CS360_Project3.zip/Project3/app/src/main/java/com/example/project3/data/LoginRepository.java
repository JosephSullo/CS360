package com.example.project3.data;

import com.example.project3.data.model.LoggedInUser;

public class LoginRepository {

    private static volatile LoginRepository instance;

    private com.example.project3.data.LoginDataSource dataSource;


    private LoggedInUser user = null;


    private LoginRepository(com.example.project3.data.LoginDataSource dataSource) {
        this.dataSource = dataSource;
    }

    public static LoginRepository getInstance(com.example.project3.data.LoginDataSource dataSource) {
        if (instance == null) {
            instance = new LoginRepository(dataSource);
        }
        return instance;
    }

    public boolean isLoggedIn() {
        return user != null;
    }

    public void logout() {
        user = null;
        dataSource.logout();
    }

    private void setLoggedInUser(LoggedInUser user) {
        this.user = user;

    }

    public Result<LoggedInUser> login(String username, String password) {

        Result<LoggedInUser> result = dataSource.login(username, password);
        if (result instanceof Result.Success) {
            setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
        }
        return result;
    }

    public Result<LoggedInUser> register(String username, String password) {
        Result<LoggedInUser> result = dataSource.register(username, password);
        if (result instanceof Result.Success) {
            setLoggedInUser(((Result.Success<LoggedInUser>) result).getData());
        }
        return result;
    }
}