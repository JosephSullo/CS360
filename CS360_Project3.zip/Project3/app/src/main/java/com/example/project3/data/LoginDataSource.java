package com.example.project3.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

import androidx.annotation.Nullable;

import com.example.project3.data.helpers.SqlDbHelper;
import com.example.project3.data.model.LoggedInUser;
import com.example.project3.data.model.SqlDbContract;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;

public class LoginDataSource {

    private SqlDbHelper DbHelper;

    public LoginDataSource(Context context) {
        DbHelper = new SqlDbHelper(context);
    }

    public Result<LoggedInUser> login(String username, String password) {

        try {

            String[] projection = {
                    BaseColumns._ID,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_PASSWORD,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_LAST_LOGIN
            };

            String selection = SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME + " = ?";
            String[] selectionArgs = { username };

            Cursor cursor = queryLoginDatabase(projection, selection, selectionArgs, null);

            HashMap row = DbHelper.GetFirst(cursor);
            if (row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME).toString().isEmpty()
                    || row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_PASSWORD).toString().isEmpty()) {
                return new Result.Error(new IOException("Error logging in"));
            }


            if (row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME).toString().equalsIgnoreCase(username)
                    && row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_PASSWORD).toString().equalsIgnoreCase(password)) {
                return new Result.Success<>(new LoggedInUser
                        (
                                row.get(SqlDbContract.AuthenticationEntry._ID).toString(),
                                row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME).toString(),
                                row.get(SqlDbContract.AuthenticationEntry.COLUMN_NAME_LAST_LOGIN).toString()
                        )
                );
            } else {
                return new Result.Error(new IOException("Error logging in"));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }


    public Result<LoggedInUser> register(String username, String password) {
        try {
            String[] projection = {
                    BaseColumns._ID,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_PASSWORD,
                    SqlDbContract.AuthenticationEntry.COLUMN_NAME_LAST_LOGIN
            };

            String selection = SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME + " = ?";
            String[] selectionArgs = { username };

            Cursor cursor = queryLoginDatabase(projection, selection, selectionArgs, null);

            HashMap row = DbHelper.GetFirst(cursor);
            if (row.isEmpty()) {

                long id = insertLoginDatabase("", username, password);

                return new Result.Success<>(new LoggedInUser
                        (
                                String.valueOf(id),
                                username,
                                ""
                        )
                );
            } else {
                return new Result.Error(new IOException("Account already registered"));
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error registering account", e));
        }
    }

    public void logout() {
    }

    private Cursor queryLoginDatabase(String[] projection, @Nullable String selection,
                                      @Nullable String[] selectionArgs, @Nullable String sortOrder) {

        SQLiteDatabase db = DbHelper.getReadableDatabase();

        return db.query(
                SqlDbContract.AuthenticationEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder
        );
    }

    private long insertLoginDatabase(String displayName, String username, String password) {

        SQLiteDatabase db = DbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SqlDbContract.AuthenticationEntry.COLUMN_NAME_NAME, displayName);
        values.put(SqlDbContract.AuthenticationEntry.COLUMN_NAME_USERNAME, username);
        values.put(SqlDbContract.AuthenticationEntry.COLUMN_NAME_PASSWORD, password);
        values.put(SqlDbContract.AuthenticationEntry.COLUMN_NAME_LAST_LOGIN, java.text.DateFormat.getDateTimeInstance().format(new Date()));

        return db.insert(SqlDbContract.AuthenticationEntry.TABLE_NAME, null, values);
    }
}