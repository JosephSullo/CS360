package com.example.project3.ui.login;

import androidx.annotation.Nullable;

class LoginResult {
    @Nullable
    private com.example.project3.ui.login.LoggedInUserView success;
    @Nullable
    private Integer error;

    LoginResult(@Nullable Integer error) {
        this.error = error;
    }

    LoginResult(@Nullable com.example.project3.ui.login.LoggedInUserView success) {
        this.success = success;
    }

    @Nullable
    com.example.project3.ui.login.LoggedInUserView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}