package com.example.project3.ui.home;

import android.content.Context;
import android.database.Cursor;
import android.provider.BaseColumns;
import android.util.Patterns;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.project3.R;
import com.example.project3.data.InventoryDataSource;
import com.example.project3.data.Result;
import com.example.project3.data.helpers.SqlDbHelper;
import com.example.project3.data.model.LoggedInUser;
import com.example.project3.data.model.SqlDbContract;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class AddDataViewModel extends ViewModel {

    private MutableLiveData<com.example.project3.ui.home.AddDataFormState> addDataFormState = new MutableLiveData<>();
    private InventoryDataSource dataSource;

    public AddDataViewModel() {
    }

    LiveData<com.example.project3.ui.home.AddDataFormState> getAddDataFormState() {
        return addDataFormState;
    }


    public void InitializeDataProvider(Context context) {
        dataSource = new InventoryDataSource(context);
    }


    public void addDataDataChanged(String productName, String productType, String productCount) {
        if (!isStringValid(productName)) {
            addDataFormState.setValue(new com.example.project3.ui.home.AddDataFormState(R.string.invalid_productName, null, null));
        } else if (!isStringValid(productType)) {
            addDataFormState.setValue(new com.example.project3.ui.home.AddDataFormState(null, R.string.invalid_productType, null));
        } else if (!isValidNumber(productCount)) {
            addDataFormState.setValue(new com.example.project3.ui.home.AddDataFormState(null, null, R.string.invalid_productCount));
        } else {
            addDataFormState.setValue(new com.example.project3.ui.home.AddDataFormState(true));
        }
    }


    public void AddRecord(String name, String type, String count) throws IOException {
        try {

            dataSource.insertInventoryDatabase(name, type, count);
        } catch (Exception e) {
            throw new IOException("Error inserting record", e);
        }
    }


    private boolean isStringValid(String sys) {
        return sys != null && sys.trim().length() > 3;
    }

    private boolean isValidNumber(String sys) {
        try {
            int i = Integer.parseInt(sys);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
