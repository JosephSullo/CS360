package com.example.project3.data;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project3.MainActivity;
import com.example.project3.R;
import com.example.project3.ui.home.EditDataFragment;
import com.example.project3.ui.home.EditDataFragmentArgs;
import com.example.project3.ui.home.HomeFragment;
import com.example.project3.ui.home.HomeFragmentDirections;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RecycleDataAdapter extends RecyclerView.Adapter<RecycleDataAdapter.ViewHolder> {
    private List<HashMap> mData;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;
    private InventoryDataSource dataSource;


    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;


    public RecycleDataAdapter(Context context, List<HashMap> data) {
        this.mInflater = LayoutInflater.from(context);
        this.dataSource = new InventoryDataSource(context);
        this.mData = data;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_warehouse, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        HashMap row = mData.get(position);

        Iterator it = row.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            switch (entry.getKey().toString()) {
                case "_id":
                    holder.itemId.setText(entry.getValue().toString());
                    break;
                case "name":
                    holder.itemName.setText(entry.getValue().toString());
                    break;
                case "type":
                    holder.itemType.setText(entry.getValue().toString());
                    break;
                case "count":
                    holder.itemCount.setText(entry.getValue().toString());
                    break;
                default:
                    break;
            }
        }
    }


    @Override
    public int getItemCount() {
        return mData.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView itemId, itemName, itemType, itemCount;
        Button deleteButton;

        ViewHolder(View itemView) {
            super(itemView);
            itemId = itemView.findViewById(R.id.item_id);
            itemName = itemView.findViewById(R.id.item_name);
            itemType = itemView.findViewById(R.id.item_type);


            itemCount = itemView.findViewById(R.id.item_count);
            itemCount.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    UpdateCountOnClick(view, itemId.getText().toString(),
                            itemCount.getText().toString());
                }
            });


            deleteButton = itemView.findViewById(R.id.delete_data);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    DeleteButtonOnClick(view, itemId.getText().toString());
                }
            });

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }


    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }


    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

    private int CalculatePosition(String id) {
        for (int counter = 0; counter < mData.size(); counter++) {
            HashMap currentRow = mData.get(counter);
            // Check to see if the strings are equal, then send the position back
            if (currentRow.get("_id").toString().equals(id)) {
                return counter;
            }
        }
        return -1;
    }

    private void UpdateCountOnClick(View view, String id, String count)
    {
        HomeFragmentDirections.ActionHomeToEdit action = HomeFragmentDirections.actionHomeToEdit(id, count);
        Navigation.findNavController(view).navigate(action);
    }

    private void DeleteButtonOnClick(View view, String id)
    {
        // Delete Entry from Database
        dataSource.deleteInventoryDatabase(id);
        // Remove Item from Items & notifychanged
        int position = CalculatePosition(id);
        mData.remove(position);
        notifyItemChanged(position);
        // Alert Record Deleted
        Snackbar.make(view, "Record Deleted!", Snackbar.LENGTH_LONG)
                .show();
    }

}